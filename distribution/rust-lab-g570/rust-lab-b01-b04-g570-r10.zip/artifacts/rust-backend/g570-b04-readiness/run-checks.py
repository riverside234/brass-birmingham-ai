import json,os,re,subprocess,sys
from pathlib import Path
root=Path.cwd();out=root/'artifacts/rust-backend/g570-b04-readiness'
env=dict(os.environ,PYTHONPATH=os.pathsep.join(str(root/n) for n in ('src','scripts','tests/R2','tests/Recovery','tests/FeatureEngineering','tests/RustBackendLab')),CUDA_VISIBLE_DEVICES='')
command=[sys.executable,'-X','utf8','-m','unittest','-v','test_b04_g570_readiness','test_b04','test_g370_lab','test_b03.Qualification','test_b03_cuda_restore','test_b03_topology','test_qualification_runner','test_lab_transfer','test_result_export']
with (out/'regression.log').open('wb') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
text=(out/'regression.log').read_text(encoding='utf-8');print(text[-2800:]);assert result.returncode==0
m=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK(?: \(skipped=(\d+)\))?\s*$',text);assert m
report=dict(passed=True,tests=int(m[1]),seconds=float(m[2]),skipped=int(m[3] or 0),command=command)
(out/'regression.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report))
