import copy,gzip,hashlib,json,sys,zipfile
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'artifacts/rust-backend/g570-b04-readiness';sys.path.insert(0,str(ROOT/'src'))
from brass_ai.recovery.source_reviews import expand_source_reviews,compact_source_reviews
from brass_ai.recovery.resume import check_signature
from brass_ai.step5.league import implementation_id,implementation_sources
from brass_ai.learning.contracts import digest
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.rust_backend.lab_prerequisite_reuse import ALLOWED
from brass_ai.rust_backend.lab_teacher_overlay import source_fingerprint

def read(p):return json.loads(p.read_bytes())
def write(p,v):p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
package=ROOT/'distribution/rust-lab-g570'
prior='8b9614d736c727d682e85753d1c851c3663461c733501eefac568624fca0dfe5'
current=implementation_id();registry=ROOT/'configs/learning/selfplay-resume-sources.json'
backup=OUT/'source-reviews-before.json';assert not backup.exists();backup.write_bytes(registry.read_bytes())
original=expand_source_reviews(read(backup));updated=copy.deepcopy(original)
reason=('B04 diagnostic-only user-authorized null utility readiness for the exact g570 checkpoint; '
        'retain original B01/B02/B02.5 and the passed r9 B03 full-state/admission qualification via exact source-delta/receipt pins. '
        'No production calibration, model, optimizer, RNG, native producer or recipe changes.')
report='ai-research/RUST_BACKEND_B04_G570_READINESS_FIX.md'
state=read(ROOT/'results/joint7-v11-2-g1290-trained-restart-g0570-20261103T190804654465Z/state.json')
for item in original['transitions']:
 if item['to_implementation']==prior:updated['transitions'].append(dict(item,to_implementation=current,reason=reason,review_report=report))
for fields in ({},{'teacher_phase_changes':True},{'config_migrations':['teacher-phase-adoption/1.0.0']}):
 updated['transitions'].append(dict(from_implementation=current,to_implementation=current,
  learning_compatibility=digest(state['signature']['compatibility']),reason=reason,review_report=report,
  preserve_g370_calibration=True,preserve_g570_calibration=True,**fields))
with zipfile.ZipFile(package/'rust-lab-b01-b04-g570-r9.zip') as archive:
 changes=[n for n,text in implementation_sources().items() if n not in archive.namelist() or archive.read(n).decode().replace('\r\n','\n')!=text]
 assert set(changes)=={'src/brass_ai/rust_backend/lab_b04_smoke.py','src/brass_ai/rust_backend/lab_prerequisite_reuse.py'},changes
 proof=json.loads(archive.read('distribution/rust-lab-g570/prerequisite-reuse.json'))
 inventory=json.loads(archive.read('artifacts/rust-backend/g570-b03-cuda/lab-evidence/evidence/b01/python-runtime-sources.json'))
write(registry,compact_source_reviews(updated));check_signature(state,dict(state['signature'],implementation=current),reviewed=True)
latest=ROOT/'results/rust-lab-qualification/20261104T020129387978Z-20261104T015819818200Z-g570-all-4c81aca9-ceb8ad68'
manifest=read(latest/'export-manifest.json');source=manifest['source_absolute'];evidence=OUT/'lab-evidence';evidence.mkdir()
selected=['evidence/b03/qualification.json','evidence/b03/restoration.json','evidence/b04/qualification.json',
          'evidence/b04/readiness.json','evidence/b04/build.json','evidence/b04/test.log','evidence/b04/fixtures.log','evidence/b04/overlay.json']
verified=[]
for name in selected:
 item=next(i for i in manifest['files'] if i['path']==name)
 raw=(latest/name).read_bytes().replace(b'\r\n',b'\n');assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['bytes'],name
 path=evidence/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);verified.append(item)
assert read(evidence/'evidence/b03/qualification.json')['passed'] is True
assert read(evidence/'evidence/b04/qualification.json')['lab']['deferred'] is True
assert read(evidence/'evidence/b04/readiness.json')['receipt'] is None
for key,subpath in [('b03','b03/qualification.json'),('b04_build','b04/build.json')]:
 item=next(i for i in verified if i['source']==subpath)
 pin=dict(path=source+'/'+subpath,bytes=item['source_bytes'],sha256=item['source_sha256'])
 if key=='b03':proof['receipts'][key]=pin
 else:proof[key]=pin
previous={i['path']:i['sha256'] for i in inventory}
proof.update(scope=['b01','b02','b025','b03'],to_implementation=current,b03_implementation=prior,
 changes={n:dict(before=previous.get(n),after=sha(ROOT/n)) for n in sorted(ALLOWED)},report=report,reason=reason,
 source_report=latest.relative_to(ROOT).as_posix())
write(package/'prerequisite-reuse.json',proof)
write(OUT/'source-review.json',dict(implementation=current,previous=prior,registry=sha(registry),
 added=len(updated['transitions'])-len(original['transitions']),reason=reason,changed_inputs=changes,verified_lab_files=verified))
print(json.dumps(dict(implementation=current,added=len(updated['transitions'])-len(original['transitions']),reuse=proof['scope'])))
