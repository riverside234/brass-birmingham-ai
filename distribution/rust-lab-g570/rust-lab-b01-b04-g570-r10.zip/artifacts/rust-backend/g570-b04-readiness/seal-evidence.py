import json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent;sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.rust_backend.lab_prerequisite_reuse import verify_delta
from brass_ai.step5.league import implementation_id
from brass_ai.rust_backend.lab_teacher_overlay import source_fingerprint
from brass_ai.recovery.resume import check_signature

def read(p):return json.loads(p.read_bytes())
def write(p,v):p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
package=ROOT/'distribution/rust-lab-g570'
with zipfile.ZipFile(package/'rust-lab-b01-b04-g570-r9.zip') as archive:
 checks=json.loads(archive.read('distribution/rust-lab-g570/local-development.json'))
 inventory=json.loads(archive.read('artifacts/rust-backend/g570-b03-cuda/lab-evidence/evidence/b01/python-runtime-sources.json'))
proof=read(package/'prerequisite-reuse.json');stamp=read(OUT/'source-review.json');tests=read(OUT/'regression.json')
assert implementation_id()==stamp['implementation'] and sha(ROOT/'configs/learning/selfplay-resume-sources.json')==stamp['registry']
assert tests['passed'] and checks['producer']==source_fingerprint()
previous={i['path']:i['sha256'] for i in inventory};current=dict(previous)
for n in proof['changes']:current[n]=sha(ROOT/n)
verify_delta(previous,current,proof)
for item in stamp['verified_lab_files']:
 p=OUT/'lab-evidence'/item['path'];assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
state=read(ROOT/'results/joint7-v11-2-g1290-trained-restart-g0570-20261103T190804654465Z/state.json')
check_signature(state,dict(state['signature'],implementation=implementation_id()),reviewed=True)
files=[*stamp['changed_inputs'],'scripts/prepare-rust-lab-g570.py','scripts/run-rust-lab-qualification.py',
       'scripts/qualify-rust-lab-b04.py','tests/RustBackendLab/test_b04_g570_readiness.py',
       'tests/RustBackendLab/test_b03_topology.py','tests/RustBackendLab/test_b03_cuda_restore.py']
review=dict(passed=True,implementation=implementation_id(),producer=source_fingerprint(),tests=tests,
 tested_files={n:sha(ROOT/n) for n in files},source_review_sha256=stamp['registry'],
 preserved_passes=proof['receipts'],reused_native_build=proof['b04_build'],prerequisites_repeated=False,
 new_games=0,optimizer_steps=0,production_modified=False,restart_at='b04',
 readiness_basis='User-authorized exact g570 null utility receipt; no calibration measurement',
 lab_qualification='B01/B02/B02.5/B03 original passes retained; B04 GPU/search Pending',
 limitations=['CPU-only development: actual CUDA and two optional native probes skipped; Windows symlink test skipped.',
              'No full games, original prerequisite qualification or native compilation repeated.'])
write(OUT/'review.json',review)
checks.update(implementation=implementation_id(),source_review_sha256=stamp['registry'],b04_g570_fix=review,
 scope='R10 pinned g570 null readiness; exact B01/B02/B02.5/B03 and tested native build reuse.',
 lab_qualification=review['lab_qualification'])
for p in OUT.rglob('*'):
 if p.is_file() and p.suffix in ('.py','.json','.log') and p.name!='source-reviews-before.json':checks['logs'][p.relative_to(ROOT).as_posix()]=sha(p)
write(package/'local-development.json',checks)
print(json.dumps(dict(passed=True,tests=tests['tests'],skipped=tests['skipped'],implementation=implementation_id())))
