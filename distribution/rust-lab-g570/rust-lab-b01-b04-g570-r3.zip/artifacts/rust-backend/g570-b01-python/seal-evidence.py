"""Bind the Python-path fix to the unchanged trainer and native producer."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).parent
PACKAGE=ROOT/'distribution/rust-lab-g570'
LAB=ROOT/'results/rust-lab-qualification/20261103T223841656406Z-20261103T223616837419Z-g570-all-2c69c499-f603530c'
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.step5.league import implementation_id,write_json
from brass_ai.rust_backend.lab_teacher_overlay import source_fingerprint
from brass_ai.rust_backend.lab_contract import sha

def result(name):
    text=(OUT/name).read_text(encoding='utf-8-sig')
    row=re.search(r'Ran (\d+) tests in ([0-9.]+)s',text)
    assert row and re.search(r'^OK\s*$',text,re.M),name
    return dict(tests=int(row[1]),seconds=float(row[2]),skipped=0)

archive=PACKAGE/'rust-lab-b01-b04-g570-r2.zip'
assert sha(archive)=='6d7c1a93d1ae9d9d010509e569bfd55801f9069b3f4c6a64233f75c58bfdafb7'
with zipfile.ZipFile(archive) as z:
    checks=json.loads(z.read('distribution/rust-lab-g570/local-development.json'))
    old=json.loads(z.read('distribution/rust-lab-g570/transfer-manifest.json'))
assert implementation_id()==checks['implementation']
assert source_fingerprint()==checks['producer']
assert sha(ROOT/'configs/learning/selfplay-resume-sources.json')==checks['source_review_sha256']
for name,expected in old['implementation_files'].items():
    assert hashlib.sha256((ROOT/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==expected,name
spec=importlib.util.spec_from_file_location('b01_python_evidence',ROOT/'scripts/qualify-rust-lab.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
adapter=result('adapter-tests.log');inference=result('existing-inference-tests.log')
assert adapter['tests']==29 and inference['tests']==28
observed={}
for name,expected in (('core-tests',70),('worker-tests',10)):
    text=(LAB/'evidence/b01'/(name+'.log')).read_text(encoding='utf-8')
    count=sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',text)))
    assert count==expected and 'test result: FAILED' not in text
    observed[name]=count
failure=(LAB/'evidence/b01/existing-inference-tests.log').read_text(encoding='utf-8')
assert failure.count("ModuleNotFoundError: No module named 'fe_fixtures'")==19
assert 'FAILED (errors=19)' in failure
assert json.loads((LAB/'evidence/runner.json').read_text())['bundle']['manifest_sha256']==hashlib.sha256(
    zipfile.ZipFile(archive).read('distribution/rust-lab-g570/transfer-manifest.json')).hexdigest()
tested=('scripts/qualify-rust-lab.py','scripts/qualify-rust-lab-b02.py','tests/RustBackendLab/test_b01_environment.py')
checks['b01_python_fix']=dict(passed=True,test_paths=list(base.TEST_PATHS),adapter=adapter,inference=inference,
    ambient_pythonpath_removed=True,tested_files={name:sha(ROOT/name) for name in tested},
    trainer_source_unchanged=True,native_source_unchanged=True,source_reviews_unchanged=True,
    lab_partial=dict(report=LAB.relative_to(ROOT).as_posix(),native_tests=observed,adapter_tests=27,
                     inference_errors=19,full_b01='Pending'))
for name in ('adapter-tests.log','existing-inference-tests.log','python-checks.log',
             'run-python-checks.py','seal-evidence.py','package-smoke.py'):
    checks['logs'][(OUT/name).relative_to(ROOT).as_posix()]=sha(OUT/name)
for name in ('core-tests.log','worker-tests.log','adapter-tests.log','existing-inference-tests.log'):
    p=LAB/'evidence/b01'/name;checks['logs'][p.relative_to(ROOT).as_posix()]=sha(p)
checks['scope']='g570-r3 Python fixture environment fix: 57 exact B01 CPU tests, clean ambient Python path, existing guarded host. '
checks['scope']+='The received r2 Linux report passed 70 core and 10 worker tests; no native rebuild was needed for this script-only change. '
checks['scope']+='Prior trainer/continuation checks retained with identical source inputs and approvals. Full B01 CUDA and later lab gates remain Pending.'
write_json(PACKAGE/'local-development.json',checks)
print(json.dumps(dict(passed=True,adapter=adapter,inference=inference,lab_qualification='Pending')),flush=True)
