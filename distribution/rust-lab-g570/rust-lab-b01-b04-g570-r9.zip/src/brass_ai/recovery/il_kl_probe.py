"""Immutable, seeded held-out IL probe; never supplies optimizer samples."""
from collections import defaultdict,deque,OrderedDict
import hashlib
import heapq
from pathlib import Path
import shutil
import time
import numpy as np
import torch

from brass_ai.bank import read,sha
from brass_ai.learning.contracts import compatibility,digest,project_path,require
from brass_ai.learning.features import Encoded,check_encoded
from brass_ai.learning.local_entities import check_action_selectors
from brass_ai.learning.batching import collate
from brass_ai.step5.league import write_json
from .il_kl_limit import GROUPS,current_config

FORMAT='fixed-il-kl-probe/1.0.0'


def semantic_hash(metadata,arrays):
    tensors=hashlib.sha256()
    for key,value in sorted(arrays.items()):tensors.update(key.encode());tensors.update(value.tobytes())
    return digest(dict({k:v for k,v in metadata.items() if k not in ('probe_hash','cache')},
                       tensors_sha256=tensors.hexdigest()))


def group_for(context):
    era={'CanalEra':'canal','RailEra':'rail'}.get(context.get('era'))
    require(era is not None and isinstance(context.get('phase'),str),'Unknown IL probe era/phase')
    return era+('_action' if context['phase']=='action' else '_other')


def select_indices(data,count,seed):
    """Balanced era x phase strata, hash priority within each, no global RNG."""
    strata=defaultdict(list)
    for i in range(len(data)):
        row=data[i][0]
        if len(row['choices'])<2:continue
        context=row['view']['context'];group_for(context)
        key=(context['era'],context['phase'])
        rank=int(digest(dict(seed=seed,index=i,identity=data[i][2])),16)
        heap=strata[key];item=(-rank,-i)
        if len(heap)<count:heapq.heappush(heap,item)
        elif item>heap[0]:heapq.heapreplace(heap,item)
    queues={key:deque(-i for _,i in sorted(items,reverse=True)) for key,items in sorted(strata.items())}
    selected=[]
    while len(selected)<count and any(queues.values()):
        for queue in queues.values():
            if queue and len(selected)<count:selected.append(queue.popleft())
    require(selected,'No nonforced IL validation positions for the anchor probe')
    return selected


def raw_probabilities(logits,mask):
    p=torch.softmax(logits.float().masked_fill(~mask.bool(),-torch.inf),dim=-1)
    require(bool(torch.isfinite(p).all()),'Non-finite fixed IL probe policy')
    return p


def stable_kl(reference,current,mask,floor):
    # Apply the same numerical floor to both raw categorical distributions.
    # This defines a proper KL and preserves KL(IL || IL)=0 even in tiny tails.
    p=reference.double().clamp_min(floor)*mask
    q=current.double().clamp_min(floor)*mask
    p=p/p.sum(-1,keepdim=True);q=q/q.sum(-1,keepdim=True)
    return (p*(p.clamp_min(1e-300).log()-q.clamp_min(1e-300).log())).sum(-1).clamp_min(0)


class Probe:
    def __init__(self,metadata,arrays,config):
        self.metadata,self.arrays,self.config=metadata,arrays,config
        self.rows=metadata['rows'];self.encoded=[]
        # Immutable INPUTS only. Never reuse predictions across weight updates.
        # Bound the CPU cache even for unusual high-candidate probes.
        self._inputs=OrderedDict();self._input_bytes=0;self._input_limit=256*1024**2
        offsets=arrays['offsets']
        require(len(offsets)==len(self.rows)+1 and offsets[0]==0 and
                offsets[-1]==len(arrays['actions']) and len(arrays['reference'])==offsets[-1],
                'Invalid fixed IL probe offsets')
        require(all(np.isfinite(v).all() for v in arrays.values()),'Non-finite fixed IL probe cache')
        for i,row in enumerate(self.rows):
            begin,end=map(int,offsets[i:i+2]);require(end-begin==len(row['kinds'])>=2,'Invalid IL probe actions')
            encoded=Encoded(arrays['states'][i],arrays['actions'][begin:end],arrays['seats'][i],tuple(row['choice_ids']))
            check_encoded(encoded);check_action_selectors(encoded.actions)
            require(row['group']==group_for(row),'Changed IL probe group')
            p=arrays['reference'][begin:end]
            require(np.all(p>=0) and abs(float(p.sum())-1)<1e-5,'Invalid cached IL probabilities')
            self.encoded.append(encoded)

    def parts(self,update):
        indices=sorted(range(len(self.rows)),key=lambda i:len(self.rows[i]['kinds']))
        part=[];maximum=0
        for i in indices:
            count=len(self.rows[i]['kinds']);maximum=max(maximum,count)
            require(count<=update['max_candidate_cells'],'IL probe position exceeds candidate budget')
            if part and (len(part)>=update['microbatch_size'] or (len(part)+1)*maximum>update['max_candidate_cells']):
                yield part;part=[];maximum=count
            part.append(i)
        if part:yield part

    def inputs(self,part,device):
        key=tuple(part)
        if key in self._inputs:
            result=self._inputs.pop(key);self._inputs[key]=result
        else:
            # collate performs the complete feature/selector admission once.
            result=collate([self.encoded[i] for i in part],'cpu')
            size=sum(t.numel()*t.element_size() for t in result)
            if size<=self._input_limit:
                while self._inputs and self._input_bytes+size>self._input_limit:
                    _,old=self._inputs.popitem(last=False)
                    self._input_bytes-=sum(t.numel()*t.element_size() for t in old)
                self._inputs[key]=result;self._input_bytes+=size
        return tuple(t.to(device) for t in result)

    def measure(self,model,update,*,reference=None,probabilities=None):
        """Operative anchor only; original-IL report-only comparisons are retired.

        KL uses all legal actions and the same double-precision floor and
        normalization as stable_kl. Bulk CPU reduction avoids thousands of
        small GPU transfers. Optional probabilities must be from these exact
        weights; the caller owns their short lifetime within one diagnostic pass.
        """
        began=time.perf_counter();offsets=self.arrays['offsets'];starts=offsets[:-1]
        lengths=np.diff(offsets)
        current=self.probabilities(model,update) if probabilities is None else probabilities
        active=self.arrays['reference'] if reference is None else reference
        for name,values in (('active anchor',active),('current probe',current)):
            require(values.shape==self.arrays['reference'].shape and
                    np.isfinite(values).all() and (values>=0).all(),'Invalid '+name+' probabilities')
            require(np.all(np.abs(np.add.reduceat(values,starts)-1)<1e-5),name+' probabilities are not normalized')
        p=np.maximum(active.astype(np.float64),self.config['probability_floor'])
        q=np.maximum(current.astype(np.float64),self.config['probability_floor'])
        p/=np.repeat(np.add.reduceat(p,starts),lengths)
        q/=np.repeat(np.add.reduceat(q,starts),lengths)
        distances=np.maximum(0.,np.add.reduceat(p*(np.log(p)-np.log(q)),starts))
        entropies=-np.add.reduceat(current*np.log(np.maximum(current,1e-30)),starts)
        normalized=entropies/np.log(lengths)
        groups={}
        for group in GROUPS:
            ids=[i for i,row in enumerate(self.rows) if row['group']==group]
            values=[distances[i] for i in ids]
            groups[group]=dict(positions=len(values),kl_mean=float(sum(values)/len(values)) if values else None,
                raw_entropy=float(np.mean(entropies[ids])) if ids else None,
                normalized_entropy=float(np.mean(normalized[ids])) if ids else None)
        result=dict(positions=len(distances),requested_positions=self.config['probe_positions'],
            kl_mean=float(distances.mean()),groups=groups,unassigned_positions=0,
            elapsed_seconds=time.perf_counter()-began,probability_floor=self.config['probability_floor'],
            input_cache_bytes=self._input_bytes,original_il_diagnostics=False,
            reference_kind='qualified_checkpoint' if reference is not None else 'initial_anchor',
            scope='Active-anchor safeguard on the existing fixed cached positions; raw T1, no exploration; no IL-data reload or separate original-IL comparison')
        return result

    def probabilities(self,model,update):
        """Raw immutable snapshot for quality-pool novelty checks, no RNG."""
        result=np.empty_like(self.arrays['reference']);device=next(model.parameters()).device
        was_training=model.training;model.eval()
        try:
            with torch.no_grad():
                for part in self.parts(update):
                    inputs=self.inputs(part,device)
                    values=raw_probabilities(model(*inputs)[0],inputs[2]).cpu().numpy()
                    for j,i in enumerate(part):
                        a,b=map(int,self.arrays['offsets'][i:i+2]);result[a:b]=values[j,:b-a]
        finally:model.train(was_training)
        return result

    def evaluate(self,model,update,*,reference=None):
        """One timed final-weight pass for the anchor and pool admission."""
        began=time.perf_counter();values=self.probabilities(model,update)
        result=self.measure(model,update,reference=reference,probabilities=values)
        result['elapsed_seconds']=time.perf_counter()-began
        return result,values

    def entropy_only(self,model,update):
        """Report-only raw T1 entropy on cached positions; no reference KL."""
        began=time.perf_counter();values=self.probabilities(model,update)
        offsets=self.arrays['offsets'];lengths=np.diff(offsets)
        entropies=-np.add.reduceat(values*np.log(np.maximum(values,1e-30)),offsets[:-1])
        normalized=entropies/np.log(lengths);groups={}
        for group in GROUPS:
            ids=[i for i,row in enumerate(self.rows) if row['group']==group]
            groups[group]=dict(positions=len(ids),raw_entropy=float(np.mean(entropies[ids])) if ids else None,
                normalized_entropy=float(np.mean(normalized[ids])) if ids else None)
        families=defaultdict(float);industries=defaultdict(float);action_positions=0;industry_mass=0.
        for i,row in enumerate(self.rows):
            if not row['group'].endswith('_action'):continue
            action_positions+=1;a,b=map(int,offsets[i:i+2])
            for kind,industry,p in zip(row['kinds'],row['industries'],values[a:b]):
                families[kind]+=float(p)
                if kind in ('build','develop') and industry is not None:
                    industries[industry]+=float(p);industry_mass+=float(p)
        return dict(positions=len(self.rows),groups=groups,raw_entropy=float(entropies.mean()),
            normalized_entropy=float(normalized.mean()),elapsed_seconds=time.perf_counter()-began,
            action_positions=action_positions,family_shares={k:v/max(1,action_positions) for k,v in families.items()},
            industry_shares={k:v/industry_mass for k,v in industries.items()} if industry_mass else {},
            input_cache_bytes=self._input_bytes,anchor_kl_measured=False,report_only=True,
            scope='Current raw T1 policy on existing fixed cached positions; no IL comparison, dataset reload, seat fingerprint input or LR gate'),values


def source_binding(root,origin):
    path=project_path(root,origin['manifest'])
    require(sha(path)==origin['manifest_sha256'],'IL probe dataset manifest changed')
    manifest=read(path)
    sources={entry['path']:entry['sha256'] for entry in manifest['entries'] if entry['split']=='validation'}
    require(sources,'No IL validation source for the fixed probe')
    for path,expected in sources.items():
        require(sha(project_path(root,path))==expected,'IL probe validation data changed: '+path)
    return dict(manifest=origin['manifest'],manifest_sha256=origin['manifest_sha256'],sources=sources,
                il_model_id=origin['model_id'],il_checkpoint_sha256=origin['sha256'],compatibility=compatibility())


def build(root,directory,origin,model,config,update,workers):
    from .demonstrations import load_dataset
    directory.mkdir(parents=True,exist_ok=True)
    source=source_binding(root,origin)
    data,_=load_dataset(root,origin['manifest'],'validation',workers=workers,progress=True,compact=True,
                        storage=directory/'.prepared')
    try:
        indices=select_indices(data,config['probe_positions'],config['probe_seed'])
        selected=[data.record(i,features=True) for i in indices]
    finally:data.close()
    rows=[];offsets=[0]
    for i,(row,_,identity,encoded) in zip(indices,selected):
        context=row['view']['context']
        rows.append(dict(index=i,identity=list(identity),era=context['era'],phase=context['phase'],
            group=group_for(context),kinds=[c['kind'] for c in row['choices']],
            industries=[c.get('industry') for c in row['choices']],chosen=row['chosen'],
            choice_ids=list(encoded.choice_ids)))
        offsets.append(offsets[-1]+len(encoded.actions))
    arrays=dict(states=np.stack([d[3].state for d in selected]),actions=np.concatenate([d[3].actions for d in selected]),
        seats=np.stack([d[3].stable_to_relative for d in selected]),offsets=np.asarray(offsets,dtype=np.int64),
        reference=np.concatenate([np.full(len(d[3].actions),1/len(d[3].actions),dtype=np.float32) for d in selected]))
    metadata=dict(format=FORMAT,source=source,config=config,rows=rows)
    probe=Probe(metadata,arrays,config);device=next(model.parameters()).device;was_training=model.training
    model.eval()
    try:
        with torch.no_grad():
            for part in probe.parts(update):
                inputs=collate([probe.encoded[i] for i in part],device)
                p=raw_probabilities(model(*inputs)[0],inputs[2]).cpu().numpy()
                for j,i in enumerate(part):
                    a,b=offsets[i:i+2];arrays['reference'][a:b]=p[j,:b-a]
    finally:model.train(was_training)
    metadata['probe_hash']=semantic_hash(metadata,arrays)
    cache=directory/'probe.npz';temporary=directory/'probe.npz.tmp'
    with temporary.open('wb') as handle:np.savez(handle,**arrays)
    temporary.replace(cache)
    metadata['cache']=dict(path=cache.relative_to(root).as_posix(),sha256=sha(cache))
    write_json(directory/'manifest.json',metadata)
    return probe,metadata


def load(root,run,origin,model,config,update,workers,receipt=None):
    directory=run/'il-kl';path=directory/'manifest.json'
    source=source_binding(root,origin)
    if path.exists():
        metadata=read(path)
        # Retiring a health-only sales field does not change fixed probe
        # selection, tensors or reference probabilities. Keep its original
        # manifest/hash/receipt; reject every other config/source difference.
        require(metadata['format']==FORMAT and current_config(metadata['config'])==current_config(config)
                and metadata['source']==source,
                'Fixed IL probe source/config differs')
        cache=project_path(root,metadata['cache']['path'])
        require(cache.parent==directory and sha(cache)==metadata['cache']['sha256'],'Fixed IL probe cache changed')
        with np.load(cache,allow_pickle=False) as file:arrays={k:file[k] for k in file.files}
        require(metadata['probe_hash']==semantic_hash(metadata,arrays),'Fixed IL probe semantic hash differs')
        probe=Probe(metadata,arrays,config)
    else:
        require(receipt is None,'Committed fixed IL probe is missing')
        probe,metadata=build(root,directory,origin,model,config,update,workers)
    current=dict(path=path.relative_to(root).as_posix(),sha256=sha(path),probe_hash=metadata['probe_hash'])
    require(receipt is None or receipt==current,'Committed fixed IL probe manifest changed')
    return probe,current


def import_probe(root,run,from_run,origin,model,config,update):
    """Copy only a committed, compatible held-out probe into a fresh run.

    The donor's large .prepared validation cache and all PPO state stay there.
    A fresh run still checks KL(IL || IL)==0 before committing its own state.
    """
    from .retention import owned,safe,active
    root,run=owned(root,run);_,donor=owned(root,from_run)
    require(donor!=run and not (run/'state.json').exists(),'Probe import requires a different, new run')
    require(not active(donor),'Stop the donor self-play run before reusing its IL probe')
    state=read(safe(donor,donor/'state.json'))
    receipt=state.get('il_kl_limit',{}).get('probe')
    require(receipt is not None,'Donor has no committed fixed IL probe; full validation cache alone is insufficient')
    entry=state['history'][-1];checkpoint=safe(donor,project_path(root,entry['path']))
    require(sha(checkpoint)==entry['sha256'],'Donor checkpoint changed')
    raw=torch.load(checkpoint,map_location='cpu',weights_only=True)
    require(raw['training'].get('il_kl_limit',{}).get('probe')==receipt,
            'Donor fixed probe differs from its committed checkpoint')
    del raw
    probe,_=load(root,donor,origin,model,config,update,1,receipt=receipt)
    directory=safe(run,run/'il-kl');directory.mkdir(parents=True,exist_ok=True)
    if (directory/'manifest.json').exists():
        existing,current=load(root,run,origin,model,config,update,1)
        require(current['probe_hash']==receipt['probe_hash'],'New run already has a different fixed IL probe')
        return existing,current
    metadata=dict(probe.metadata);source=project_path(root,metadata['cache']['path'])
    target=safe(run,directory/'probe.npz');temporary=safe(run,directory/'probe.npz.tmp')
    try:
        shutil.copyfile(source,temporary)
        require(sha(temporary)==metadata['cache']['sha256'],'IL probe changed during copy')
        temporary.replace(target)
    finally:temporary.unlink(missing_ok=True)
    metadata['cache']=dict(path=target.relative_to(root).as_posix(),sha256=sha(target))
    require(semantic_hash(metadata,probe.arrays)==receipt['probe_hash'],'Imported IL probe identity changed')
    path=directory/'manifest.json';write_json(path,metadata)
    current=dict(path=path.relative_to(root).as_posix(),sha256=sha(path),probe_hash=metadata['probe_hash'])
    write_json(directory/'import-report.json',dict(format='fixed-il-probe-import/1.0.0',
        source_run=donor.relative_to(root).as_posix(),source_receipt=receipt,destination_receipt=current,
        copied_bytes=target.stat().st_size,training_state_imported=False))
    print(f'Reused fixed IL validation probe: {len(probe.rows)} positions from {from_run}; no validation re-encoding',flush=True)
    return Probe(metadata,probe.arrays,config),current
