"""Verify r4 transport and equality to the r3 payload that passed all 57 tests."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_transfer import DIRECTORY,verify
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.step5.league import write_json

receipt=json.loads((ROOT/DIRECTORY/'bundle.json').read_text(encoding='utf-8'))
manifest=json.loads((ROOT/DIRECTORY/'transfer-manifest.json').read_text(encoding='utf-8'))
prior=json.loads((OUT/'r3-package-check.json').read_text(encoding='utf-8'))
assert prior['passed'] and prior['exact_b01_cpu_gates']=={'adapter-tests':29,'existing-inference-tests':28}
assert receipt['path'].endswith('rust-lab-b01-b04-g570-r4.zip')
stages=[verify(stage) for stage in ('b01','b02','b025','b03','b04')]
detached=ROOT/'artifacts/r4';assert not detached.exists()
prefixes=('src/','configs/','native/','lab-native/','tests/','training/runtime/','scripts/')
def executed(names):
    return {n for n in names if n.startswith(prefixes) and n!='scripts/prepare-rust-lab-g570.py'}
with zipfile.ZipFile(ROOT/prior['archive']['path']) as old,zipfile.ZipFile(ROOT/receipt['path']) as new:
    assert new.testzip() is None
    assert sha(ROOT/prior['archive']['path'])==prior['archive']['sha256']
    tested=executed(old.namelist());assert tested==executed(new.namelist())
    for name in tested:assert old.read(name)==new.read(name),name
    for name,expected in manifest['files'].items():
        raw=new.read(name)
        assert raw==(ROOT/name).read_bytes(),name
        assert hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()==expected,name
    for name,expected in manifest['archives'].items():
        assert hashlib.sha256(new.read(name)).hexdigest()==expected,name
    assert not any(n.startswith('results/rust-lab-qualification/') and n!='results/rust-lab-qualification/README.md'
                   for n in new.namelist())
    new.extractall(detached)
shutil.copyfile(ROOT/DIRECTORY/'bundle.json',detached/DIRECTORY/'bundle.json')
shutil.copyfile(ROOT/receipt['path'],detached/receipt['path'])
env=dict(os.environ,PYTHONPATH=str(detached/'src'))
argv=[sys.executable,'-X','utf8','-c',
      'from brass_ai.rust_backend.lab_transfer import verify; '
      'print([verify(s)["milestone"] for s in ("b01","b02","b025","b03","b04")])']
with (OUT/'r4-extracted-integrity.log').open('w',encoding='utf-8') as log:
    run=subprocess.run(argv,cwd=detached,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
assert run.returncode==0,run.returncode
value=dict(passed=True,local_date='2026-11-03',archive=receipt,transfer_stages=stages,
    raw_payload_and_crc='passed',fresh_extraction_integrity='passed',unchanged_executable_config_test_files=len(tested),
    exact_b01_cpu_gates=prior['exact_b01_cpu_gates'],cpu_execution_evidence=dict(archive=prior['archive'],
        receipt_sha256=sha(OUT/'r3-package-check.json'),scope='57 tests executed from r3; every executable/config/test input is byte-identical in r4'),
    original_result_folders_untouched=True,lab_log_copies_match_original_exports=True,
    lab_qualification='Pending',scope='R4 transport verification and exact equality to tested r3; actual g570/CUDA gates require lab rerun',
    logs={(OUT/n).relative_to(ROOT).as_posix():sha(OUT/n) for n in ('r4-extracted-integrity.log','package-verify-r4.py')})
write_json(OUT/'package-check-r4.json',value)
write_json(ROOT/DIRECTORY/'package-check.json',value)
print(json.dumps(dict(passed=True,unchanged_tested_inputs=len(tested),b01_cpu_tests=57,lab_qualification='Pending')),flush=True)
