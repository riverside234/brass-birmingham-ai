"""Run the actual B01 CPU commands from the r3 archive with clean imports."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_transfer import DIRECTORY,RETIRED,verify
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.step5.league import write_json

receipt=json.loads((ROOT/DIRECTORY/'bundle.json').read_text(encoding='utf-8'))
manifest=json.loads((ROOT/DIRECTORY/'transfer-manifest.json').read_text(encoding='utf-8'))
assert receipt['path'].endswith('rust-lab-b01-b04-g570-r3.zip')
stages=[verify(stage) for stage in ('b01','b02','b025','b03','b04')]
archive=ROOT/receipt['path'];detached=OUT/'extracted-package'
assert not detached.exists()
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not set(RETIRED).intersection(z.namelist())
    for name,expected in manifest['files'].items():
        raw=z.read(name)
        assert raw==(ROOT/name).read_bytes(),name
        assert hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()==expected,name
    for name,expected in manifest['archives'].items():
        assert hashlib.sha256(z.read(name)).hexdigest()==expected,name
    z.extractall(detached)
shutil.copyfile(ROOT/DIRECTORY/'bundle.json',detached/DIRECTORY/'bundle.json')
shutil.copyfile(archive,detached/receipt['path'])
# Supply the same existing prerequisite as the lab. It is deliberately outside
# the distributable ZIP, and every copied runtime dependency remains pinned.
runtime=ROOT/'artifacts/r1-host/guarded'
runtime_manifest=json.loads((runtime/'runtime.json').read_text(encoding='utf-8-sig'))
runtime_out=detached/'artifacts/r1-host/guarded';runtime_out.mkdir(parents=True)
for entry in runtime_manifest['files']:
    source=runtime/entry['name'];target=runtime_out/entry['name']
    assert source.resolve().parent==runtime.resolve() and target.resolve().parent==runtime_out.resolve()
    assert sha(source)==entry['sha256'],entry['name']
    shutil.copyfile(source,target)
shutil.copyfile(runtime/'runtime.json',runtime_out/'runtime.json')
env=dict(os.environ);env.pop('PYTHONPATH',None)
command=[sys.executable,'-X','utf8',str(detached/'artifacts/rust-backend/g570-b01-python/run-python-checks.py'),
         str(detached),str(OUT/'extracted-cpu')]
with (OUT/'extracted-console.log').open('w',encoding='utf-8') as log:
    run=subprocess.run(command,cwd=detached,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert run.returncode==0,run.returncode
result=json.loads((OUT/'extracted-cpu/python-checks.json').read_text(encoding='utf-8'))
assert result['passed'] and result['ambient_pythonpath_removed']
for name in result['pythonpath'].split(os.pathsep):
    assert Path(name).is_relative_to(detached)
counts={}
for name in ('adapter-tests','existing-inference-tests'):
    text=(OUT/'extracted-cpu'/(name+'.log')).read_text(encoding='utf-8')
    row=re.search(r'Ran (\d+) tests in ([0-9.]+)s',text)
    assert row and re.search(r'^OK\s*$',text,re.M),name
    counts[name]=int(row[1])
assert counts=={'adapter-tests':29,'existing-inference-tests':28}
for path in (ROOT/DIRECTORY).iterdir():
    assert subprocess.run(['git','check-ignore','-q','--no-index',path.relative_to(ROOT).as_posix()],cwd=ROOT).returncode==1,path
value=dict(passed=True,local_date='2026-11-03',archive=receipt,transfer_stages=stages,
    raw_payload_and_crc='passed',exact_b01_cpu_gates=counts,ambient_pythonpath_removed=True,
    runtime_supplied_separately=dict(manifest_sha256=sha(runtime/'runtime.json'),files=len(runtime_manifest['files'])),
    native_source_unchanged=True,lab_qualification='Pending',
    scope='Fresh-archive Windows B01 CPU suites with real existing rules runtime; actual g570/CUDA gates require lab rerun',
    logs={(OUT/n).relative_to(ROOT).as_posix():sha(OUT/n) for n in
        ('extracted-console.log','extracted-cpu/python-checks.json',
         'extracted-cpu/adapter-tests.log','extracted-cpu/existing-inference-tests.log')})
write_json(OUT/'package-check.json',value)
write_json(ROOT/DIRECTORY/'package-check.json',value)
print(json.dumps(dict(passed=True,exact_b01_cpu_gates=counts,lab_qualification='Pending')),flush=True)
