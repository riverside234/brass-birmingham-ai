"""Invoke the real B01 CPU gate helper from the selected checkout."""
import importlib.util
import json
import os
from pathlib import Path
import sys

root=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve()
out.mkdir(parents=True,exist_ok=False)
spec=importlib.util.spec_from_file_location('b01_exact_cpu_gates',root/'scripts/qualify-rust-lab.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
ambient=dict(os.environ);ambient.pop('PYTHONPATH',None)
env=base.python_environment(ambient)
commands=base.python_checks(out,env)
base.write(out/'python-checks.json',dict(passed=True,ambient_pythonpath_removed=True,
    pythonpath=env['PYTHONPATH'],commands=commands,lab_qualification='Pending',
    scope='Exact B01 adapter and existing inference CPU gates; existing private rules runtime, no CUDA/checkpoint load'))
print(json.dumps(dict(passed=True,checks=len(commands),lab_qualification='Pending')),flush=True)
