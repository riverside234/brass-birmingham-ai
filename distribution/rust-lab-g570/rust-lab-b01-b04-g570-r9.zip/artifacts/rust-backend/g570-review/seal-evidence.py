"""Verify received lab bytes and bind the short r5 checks to unchanged producers."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT/'src'))
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.rust_backend.lab_teacher_overlay import source_fingerprint
from brass_ai.step5.league import implementation_id, write_json


def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))


def test_summary(path):
    text = path.read_text(encoding='utf-8')
    match = re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK(?: \(skipped=(\d+)\))?\s*$', text)
    assert match, path
    return dict(tests=int(match[1]), seconds=float(match[2]), skipped=int(match[3] or 0))


def main():
    package = ROOT/'distribution/rust-lab-g570'
    checks = read(package/'local-development.json')
    assert checks['implementation'] == implementation_id() == '70a926e5dfc7aa30829c296b49cb7b53159534ccc5e7c8876c46a9609a44164d'
    assert checks['producer'] == source_fingerprint() == 'bc2c07c397fdc979c9d4376189e723af86620e6361e3cd7052f3500cea3709cb'
    assert checks['source_review_sha256'] == sha(ROOT/'configs/learning/selfplay-resume-sources.json')
    evidence = OUT/'lab-evidence'
    exported = read(evidence/'export-manifest.json')
    verified = []
    for item in exported['files']:
        path = evidence/item['path']
        if not path.exists(): continue
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], item['path']
        verified.append(item['path'])
    lab = read(evidence/'evidence/runner.json')
    b01 = read(evidence/'evidence/b01/qualification.json')
    gpu = read(evidence/'evidence/b01/gpu-0.json')
    assert not lab['passed'] and [(r['stage'], r['passed']) for r in lab['stages']] == [('b01', True), ('b02', False)]
    assert b01['passed'] and gpu['passed'] and gpu['device'] == 'cuda:0'
    assert b01['python_sources']['sha256'] == sha(evidence/'evidence/b01/python-runtime-sources.json')
    immutable = ('src/', 'configs/', 'lab-native/', 'native/', 'training/runtime/')
    unchanged = []
    with zipfile.ZipFile(package/'rust-lab-b01-b04-g570-r4.zip') as archive:
        for name in archive.namelist():
            if name.startswith(immutable):
                assert archive.read(name) == (ROOT/name).read_bytes(), name
                unchanged.append(name)
    # Compare the lab's runtime/source inventory, allowing only Git CRLF
    # conversion for this cross-platform review. Live B02 still checks raw pins.
    recorded = read(evidence/'evidence/b01/python-runtime-sources.json')
    matches = []; differences = []
    for item in recorded:
        name = item['path']
        if not name.startswith(('src/', 'configs/', 'training/runtime/')): continue
        path = ROOT/name
        if path.is_file():
            raw = path.read_bytes()
            if item['sha256'] in (hashlib.sha256(raw).hexdigest(), hashlib.sha256(raw.replace(b'\r\n', b'\n')).hexdigest()):
                matches.append(name); continue
        differences.append(name)
    assert not differences, differences
    harness = test_summary(OUT/'harness-pass/tests.log')
    training = test_summary(OUT/'training-fixtures/tests.log')
    adapter = test_summary(OUT/'b01-python/adapter-tests.log')
    inference = test_summary(OUT/'b01-python/existing-inference-tests.log')
    assert harness['tests'] == 39 and training['tests'] == 72 and adapter['tests'] == 29 and inference['tests'] == 28
    bootstrap = read(OUT/'bootstrap/bootstrap-smoke.json')
    assert bootstrap['passed'] and bootstrap['checkpoint_restored']
    tested = ['scripts/qualify-rust-lab.py', 'scripts/qualify-rust-lab-b02.py',
        'scripts/run-rust-lab-qualification.py', 'scripts/rust_lab_toolchain.py', 'scripts/rust_lab_results.py',
        'tests/RustBackendLab/test_qualification_runner.py', 'tests/RustBackendLab/test_result_export.py',
        'tests/RustBackendLab/test_b02.py', 'tests/RustBackendLab/test_b025.py', 'tests/RustBackendLab/test_b03.py',
        'tests/RustBackendLab/test_b04.py', 'tests/RustBackendLab/test_g370_lab.py', 'tests/RustBackendLab/test_lab_transfer.py']
    report = dict(passed=True, b01_lab_passed=True, runtime_sources_unchanged=True,
        unchanged_r4_runtime_inputs=len(unchanged), matched_lab_source_runtime_files=len(matches),
        lab_report='results/rust-lab-qualification/20261103T232335735601Z-20261103T232040081783Z-g570-all-fc1a5f74-025ddb53',
        lab_commit='bea9eb6185ec501a19c27c0b30484ff3bb2d838c', received_files_verified=verified,
        local=dict(harness=harness, training=training, b01_adapter=adapter, b01_inference=inference),
        bootstrap=bootstrap, tested_files={n:sha(ROOT/n) for n in tested},
        scope='Qualification harness only; same trainer/native core/source approvals. B01 Linux/CUDA passed in received report; B02-B04 real lab gates remain Pending.')
    write_json(OUT/'review.json', report)
    checks['qualification_review'] = report
    checks['b01_python_fix'].update(adapter=adapter, inference=inference,
        tested_files={n:sha(ROOT/n) for n in checks['b01_python_fix']['tested_files']})
    checks['scope'] = report['scope']
    checks['lab_qualification'] = 'B01 passed for g570/cuda:0; B02-B04 Pending'
    logs = [OUT/'run-checks.py', OUT/'seal-evidence.py', OUT/'package-check.py', OUT/'review.json', evidence/'export-manifest.json']
    logs += [evidence/n for n in verified]
    for folder in ('harness-pass', 'training-fixtures', 'b01-python', 'bootstrap'):
        logs += [p for p in (OUT/folder).iterdir() if p.is_file() and p.suffix in ('.json', '.log')]
    checks['logs'].update({p.relative_to(ROOT).as_posix():sha(p) for p in logs})
    write_json(package/'local-development.json', checks)
    print(json.dumps(dict(passed=True, tests=sum(r['tests'] for r in report['local'].values()),
        skipped=sum(r['skipped'] for r in report['local'].values()), matched_runtime=len(matches))))


if __name__ == '__main__': main()
