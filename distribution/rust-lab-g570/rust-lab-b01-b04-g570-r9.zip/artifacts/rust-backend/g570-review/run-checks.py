"""Short development checks for the g570-r5 qualification harness."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT/'src'))


def module(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), ROOT/'scripts'/name)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--bootstrap', action='store_true')
    parser.add_argument('tests', nargs='*')
    args = parser.parse_args()
    base = module('qualify-rust-lab.py')
    args.out.mkdir(parents=True, exist_ok=False)
    env = base.python_environment()
    env['CUDA_VISIBLE_DEVICES'] = ''
    if args.bootstrap:
        value = module('qualify-rust-lab-b02.py').build_bootstrap(args.out, env, base.command, 'mono')
    else:
        value = base.command([sys.executable, '-m', 'unittest', '-v', *args.tests],
            cwd=ROOT, env=env, log=args.out/'tests.log', timeout=150)
    base.write(args.out/'checks.json', dict(passed=True, result=value))
    print(json.dumps(dict(passed=True, receipt=str(args.out/'checks.json'))))


if __name__ == '__main__': main()
