"""Seal r8 diagnostics; retain successful r7 evidence without rerunning it."""
import json,re,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.step5.league import implementation_id
from brass_ai.recovery.resume import check_signature
from brass_ai.rust_backend.lab_prerequisite_reuse import ALLOWED,verify_delta

def read(p):return json.loads(Path(p).read_bytes())
def write(p,v):p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
def summary(p):
    match=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK(?: \(skipped=(\d+)\))?\s*$',p.read_text(encoding='utf-8'))
    assert match,p
    return dict(tests=int(match[1]),seconds=float(match[2]),skipped=int(match[3] or 0))
package=ROOT/'distribution/rust-lab-g570'
with zipfile.ZipFile(package/'rust-lab-b01-b04-g570-r7.zip') as archive:
    checks=json.loads(archive.read('distribution/rust-lab-g570/local-development.json'))
stamp=read(OUT/'source-review.json');registry=ROOT/'configs/learning/selfplay-resume-sources.json'
assert sha(registry)==stamp['registry'] and implementation_id()==stamp['implementation']
state=read(ROOT/'results/joint7-v11-2-g1290-trained-restart-g0570-20261103T190804654465Z/state.json')
check_signature(state,dict(state['signature'],implementation=implementation_id()),reviewed=True)
tests=summary(OUT/'regression/tests.log')
evidence=OUT/'lab-evidence';exported=read(evidence/'export-manifest.json');verified=[]
for item in exported['files']:
    path=evidence/item['path']
    if path.exists():
        assert sha(path)==item['sha256'] and path.stat().st_size==item['bytes'],item['path']
        verified.append(item['path'])
proof=read(package/'prerequisite-reuse.json')
previous={i['path']:i['sha256'] for i in read(evidence/'evidence/b01/python-runtime-sources.json')}
after=dict(previous)
for name in ALLOWED:after[name]=sha(ROOT/name)
verify_delta(previous,after,proof)
assert all(read(evidence/f'evidence/{stage}/qualification.json')['passed'] for stage in ('b01','b02','b025'))
assert not read(evidence/'evidence/b03/qualification.json')['passed']
files=[*stamp['changed_inputs'],'scripts/prepare-rust-lab-g570.py','scripts/qualify-rust-lab-b02.py',
    'scripts/qualify-rust-lab-b03.py','tests/RustBackendLab/test_b03_cuda_restore.py']
review=dict(passed=True,implementation=implementation_id(),worker_cap=60,tests=tests,
    tested_files={name:sha(ROOT/name) for name in files},verified_lab_files=verified,
    source_review_sha256=sha(registry),prerequisite_review_sha256=sha(package/'prerequisite-reuse.json'),
    preserved_passes=proof['receipts'],restart_at='b03',new_games=0,
    lab_qualification='B01/B02/B02.5 passing original scopes retained; B03/B04 Pending',
    limitations=['Local PyTorch is CPU-only: actual CUDA payload test and two native overlay probes skipped.',
                'No previously successful lab qualification or full-game collection was repeated.'])
write(OUT/'review.json',review)
checks.update(implementation=implementation_id(),source_review_sha256=sha(registry),b03_cuda_fix=review,
    scope='R8 diagnostic CUDA comparator and exact prerequisite reuse; successful B01/B02/B02.5 evidence retained.',
    lab_qualification=review['lab_qualification'])
# Keep historical B01 test source pins and logs verbatim. The changed B02
# prerequisite guard is bound separately to the new focused regression suite.
logs=[p for p in OUT.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.py') and p.name!='source-reviews-before.json']
checks['logs'].update({p.relative_to(ROOT).as_posix():sha(p) for p in logs})
write(package/'local-development.json',checks)
print(json.dumps(dict(passed=True,tests=tests,implementation=implementation_id(),restart_at='b03')))
