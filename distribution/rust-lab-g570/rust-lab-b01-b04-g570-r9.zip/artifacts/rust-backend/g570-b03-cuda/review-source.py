"""Review diagnostic-only r8 changes and preserve exact successful prerequisites."""
import copy,json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.recovery.source_reviews import expand_source_reviews,compact_source_reviews
from brass_ai.step5.league import implementation_id,implementation_sources
from brass_ai.learning.contracts import digest
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.rust_backend.lab_prerequisite_reuse import ALLOWED
from brass_ai.rust_backend.lab_teacher_overlay import source_fingerprint
from brass_ai.recovery.resume import check_signature

def read(path):return json.loads(path.read_bytes())
def write(path,value):path.write_bytes((json.dumps(value,indent=2,allow_nan=False)+'\n').encode())
registry=ROOT/'configs/learning/selfplay-resume-sources.json'
backup=OUT/'source-reviews-before.json';assert not backup.exists()
backup.write_bytes(registry.read_bytes());before=sha(registry)
original=expand_source_reviews(read(backup));updated=copy.deepcopy(original)
current=implementation_id();prior='a7d39190382b768058f699ba94a8e870b7ca18eb54c636392fc2eeec6b8dc31b'
state=read(ROOT/'results/joint7-v11-2-g1290-trained-restart-g0570-20261103T190804654465Z/state.json')
reason=('B03 diagnostic verification repair: compare exact detached CPU copies of restored CUDA Adam/PPG/auxiliary '
        'payload tensors without modifying their values/devices. Reuse the exact passing r7 B01/B02/B02.5 '
        'receipts under an enumerated, sealed source-delta review; all other source/runtime/receipt and run pins '
        'remain mandatory. No collector, search, model, optimizer-update, RNG or recipe changes; B03/B04 Pending.')
for item in original['transitions']:
    if item['to_implementation']==prior:
        updated['transitions'].append(dict(item,to_implementation=current,reason=reason,
            review_report='ai-research/RUST_BACKEND_B03_CUDA_RESTORE_FIX.md'))
for fields in ({},{'teacher_phase_changes':True},{'config_migrations':['teacher-phase-adoption/1.0.0']}):
    updated['transitions'].append(dict(from_implementation=current,to_implementation=current,
        learning_compatibility=digest(state['signature']['compatibility']),reason=reason,
        review_report='ai-research/RUST_BACKEND_B03_CUDA_RESTORE_FIX.md',preserve_g370_calibration=True,
        preserve_g570_calibration=True,**fields))
with zipfile.ZipFile(ROOT/'distribution/rust-lab-g570/rust-lab-b01-b04-g570-r7.zip') as archive:
    changes=[name for name,text in implementation_sources().items() if name not in archive.namelist()
        or archive.read(name).decode('utf-8').replace('\r\n','\n')!=text]
assert set(changes)==ALLOWED-{'configs/learning/selfplay-resume-sources.json'},changes
assert sha(registry)==before;write(registry,compact_source_reviews(updated))
check_signature(state,dict(state['signature'],implementation=current),reviewed=True)
write(OUT/'source-review.json',dict(implementation=current,previous=prior,registry=sha(registry),
    added=len(updated['transitions'])-len(original['transitions']),reason=reason,changed_inputs=changes))
evidence=OUT/'lab-evidence';exported=read(evidence/'export-manifest.json')
for item in exported['files']:
    path=evidence/item['path']
    if path.exists():
        path.write_bytes(path.read_bytes().replace(b'\r\n',b'\n'))
        assert sha(path)==item['sha256'] and path.stat().st_size==item['bytes'],item['path']
receipt_refs={}
root=exported['source_absolute']
for stage in ('b01','b02','b025'):
    entry=next(i for i in exported['files'] if i['path']==f'evidence/{stage}/qualification.json')
    assert read(evidence/entry['path'])['passed'] is True
    receipt_refs[stage]=dict(path=root+'/'+stage+'/qualification.json',bytes=entry['bytes'],sha256=entry['sha256'])
previous={i['path']:i['sha256'] for i in read(evidence/'evidence/b01/python-runtime-sources.json')}
proof=dict(contract='brass-lab-prerequisite-reuse/1.0.0',scope=['b01','b02','b025'],
    from_implementation=prior,to_implementation=current,producer=source_fingerprint(),receipts=receipt_refs,
    changes={name:dict(before=previous.get(name),after=sha(ROOT/name)) for name in sorted(ALLOWED)},
    report='ai-research/RUST_BACKEND_B03_CUDA_RESTORE_FIX.md',reason=reason,
    source_report='results/rust-lab-qualification/20261104T012220551953Z-20261104T011422740838Z-g570-all-8bee9d91-e1605e8c')
write(ROOT/'distribution/rust-lab-g570/prerequisite-reuse.json',proof)
print(json.dumps(dict(implementation=current,added=len(updated['transitions'])-len(original['transitions']),reuse=list(receipt_refs))))
