"""Exact continuation reviews for the bounded B02 transport/diagnostic repair."""
import copy,json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.recovery.source_reviews import expand_source_reviews,compact_source_reviews
from brass_ai.step5.league import implementation_id,implementation_sources
from brass_ai.learning.contracts import digest
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.recovery.resume import check_signature

def write(path,value):path.write_bytes((json.dumps(value,indent=2,allow_nan=False)+'\n').encode())
registry=ROOT/'configs/learning/selfplay-resume-sources.json'
backup=OUT/'source-reviews-before.json';assert not backup.exists()
backup.write_bytes(registry.read_bytes());before=sha(registry)
original=expand_source_reviews(json.loads(backup.read_bytes()))
updated=copy.deepcopy(original);current=implementation_id()
prior='20efa9ea06dad63f8301f0352d56f254c245b0a138caea2bd529dfc17873629e'
state=json.loads((ROOT/'results/joint7-v11-2-g1290-trained-restart-g0570-20261103T190804654465Z/state.json').read_bytes())
reason=('B02 timeout repair: buffer the existing bounded C# JSON transport, reuse exact step/restore decisions, '
        'reuse the independent feature encoder instance, and record bounded progress/stacks. '
        'No rule, model, optimizer, RNG, sampling, search or recipe change; all correctness gates and '
        '240-second watchdog retained. Full g570 continuation preserved; Linux/CUDA qualification Pending.')
for item in original['transitions']:
    if item['to_implementation']==prior:
        updated['transitions'].append(dict(item,to_implementation=current,reason=reason,
            review_report='ai-research/RUST_BACKEND_B02_TIMEOUT_FIX.md'))
for fields in ({},{'teacher_phase_changes':True},{'config_migrations':['teacher-phase-adoption/1.0.0']}):
    updated['transitions'].append(dict(from_implementation=current,to_implementation=current,
        learning_compatibility=digest(state['signature']['compatibility']),reason=reason,
        review_report='ai-research/RUST_BACKEND_B02_TIMEOUT_FIX.md',preserve_g370_calibration=True,
        preserve_g570_calibration=True,**fields))
with zipfile.ZipFile(ROOT/'distribution/rust-lab-g570/rust-lab-b01-b04-g570-r6.zip') as archive:
    changes=[name for name,text in implementation_sources().items() if name not in archive.namelist()
        or archive.read(name).decode('utf-8').replace('\r\n','\n')!=text]
assert set(changes)=={'src/brass_ai/rust_backend/lab_transport.py',
    'src/brass_ai/rust_backend/lab_b02_smoke.py','src/brass_ai/rust_backend/lab_smoke_progress.py'},changes
assert sha(registry)==before
write(registry,compact_source_reviews(updated))
check_signature(state,dict(state['signature'],implementation=current),reviewed=True)
write(OUT/'source-review.json',dict(implementation=current,previous=prior,registry=sha(registry),
    added=len(updated['transitions'])-len(original['transitions']),reason=reason,changed_inputs=changes))
print(current)
