"""Bind r7's short regression evidence and exact checkpoint continuation."""
import json,re,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.step5.league import implementation_id
from brass_ai.recovery.resume import check_signature

def read(p):return json.loads(Path(p).read_bytes())
def write(p,v):p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
def summary(p):
    text=p.read_text(encoding='utf-8');match=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK(?: \(skipped=(\d+)\))?\s*$',text)
    assert match,p
    return dict(tests=int(match[1]),seconds=float(match[2]),skipped=int(match[3] or 0))

package=ROOT/'distribution/rust-lab-g570'
with zipfile.ZipFile(package/'rust-lab-b01-b04-g570-r6.zip') as archive:
    checks=json.loads(archive.read('distribution/rust-lab-g570/local-development.json'))
stamp=read(OUT/'source-review.json');registry=ROOT/'configs/learning/selfplay-resume-sources.json'
assert sha(registry)==stamp['registry'] and implementation_id()==stamp['implementation']
state=read(ROOT/'results/joint7-v11-2-g1290-trained-restart-g0570-20261103T190804654465Z/state.json')
check_signature(state,dict(state['signature'],implementation=implementation_id()),reviewed=True)
tests={name:summary(OUT/path) for name,path in [('focused','focused-pass/tests.log'),
    ('continuation','continuation/tests.log'),('b01_adapter','b01/adapter-tests.log'),
    ('b01_inference','b01/existing-inference-tests.log')]}
evidence=OUT/'lab-evidence';exported=read(evidence/'export-manifest.json');verified=[]
for item in exported['files']:
    p=evidence/item['path']
    if p.exists():
        # Restore connector UTF-8 text to the exact exported LF bytes.
        raw=p.read_bytes().replace(b'\r\n',b'\n');p.write_bytes(raw)
        assert sha(p)==item['sha256'] and len(raw)==item['bytes'],item['path']
        verified.append(item['path'])
assert 'timed out after 240 seconds' in read(evidence/'evidence/b02/qualification.json')['error']
bench=read(OUT/'transport-benchmark.json');oracle=read(OUT/'oracle-smoke.json')
assert bench['speedup']>10 and oracle['passed'] and sum(len(v['checks']) for v in oracle['lanes'])==48
files=[*stamp['changed_inputs'],'scripts/prepare-rust-lab-g570.py','tests/RustBackendLab/test_b02_timeout.py']
review=dict(passed=True,implementation=implementation_id(),worker_cap=60,smoke_watchdog_seconds=240,
    tests=tests,tested_files={n:sha(ROOT/n) for n in files},source_review_sha256=sha(registry),
    verified_lab_files=verified,transport_benchmark=bench,oracle_smoke=oracle,
    lab_qualification='Pending: rerun B01-B04 for changed executable source',
    limitations=['Two optional built-native teacher probes skipped; actual Linux/CUDA gate remains on lab.',
        'Transport measurement is local Windows oracle IPC only, not a whole-game or Linux speedup.'])
write(OUT/'review.json',review)
checks.update(implementation=implementation_id(),source_review_sha256=sha(registry),collection_timeout_fix=review,
    scope='R7 buffered text oracle transport, exact decision reuse and watchdog diagnostics; full g570 continuation preserved.',
    lab_qualification='Pending')
checks['b01_python_fix'].update(adapter=tests['b01_adapter'],inference=tests['b01_inference'],
    trainer_source_unchanged=False,source_reviews_unchanged=False)
checks['b01_python_fix']['tested_files']={n:sha(ROOT/n) for n in checks['b01_python_fix']['tested_files']}
logs=[p for p in OUT.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.py') and p.name!='source-reviews-before.json']
checks['logs'].update({p.relative_to(ROOT).as_posix():sha(p) for p in logs})
write(package/'local-development.json',checks)
print(json.dumps(dict(passed=True,tests=tests,implementation=implementation_id())))
