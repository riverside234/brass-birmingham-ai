"""Short real oracle progression, decision reuse and shuffled fork restore."""
import json,sys,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_b02_smoke import Oracle
from brass_ai.rust_backend.lab_transport import Pipe
HOST=ROOT/'artifacts/r6/artifacts/r6-host/bootstrap/BrassLabBootstrap.exe'

def check(seed):
    began=time.monotonic();checks=[];restored=False
    with Pipe([HOST],binary=False) as pipe:
        pipe.call('init',seed=seed);oracle=Oracle(pipe)
        for step in range(12):
            decision=oracle.decision()
            assert decision==pipe.call('decision')
            if decision['context']['terminal']:break
            checks.append(dict(step=step,candidates=len(decision['choices']),phase=decision['context']['phase']))
            checkpoint=pipe.call('checkpoint')
            oracle.step(decision['choices'][0]['id'])
            assert oracle.decision()==pipe.call('decision')
            if step>=3 and not restored and decision['context']['phase']=='action':
                oracle.restore(checkpoint,7129)
                assert oracle.decision()==pipe.call('decision')
                restored=True
        assert restored
        return dict(seed=seed,checks=checks,seconds=time.monotonic()-began,shuffled_restore=restored)

with ThreadPoolExecutor(max_workers=4) as pool:
    result=list(pool.map(check,[19281829,19281831,19281893,153]))
value=dict(passed=True,lanes=result,scope='48 bounded decisions, exact next-reply parity and shuffled fork restore; no full games')
(OUT/'oracle-smoke.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(dict(passed=True,decisions=sum(len(r['checks']) for r in result),max_seconds=max(r['seconds'] for r in result))))
