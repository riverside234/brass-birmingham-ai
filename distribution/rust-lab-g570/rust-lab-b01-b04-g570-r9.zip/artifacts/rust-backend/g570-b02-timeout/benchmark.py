"""Bounded real C# oracle transport benchmark; no whole games or training."""
import io,json,statistics,sys,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_transport import Pipe

HOST=ROOT/'artifacts/r6/artifacts/r6-host/bootstrap/BrassLabBootstrap.exe'

def lane(buffered):
    with Pipe([HOST],binary=False) as pipe:
        if not buffered:
            # Reproduce r6's FileIO.readline on exactly the same oracle replies.
            pipe.process.stdout=pipe.process.stdout.detach()
        pipe.call('init',seed=19281829)
        checkpoint=pipe.call('checkpoint')
        initial=pipe.call('decision')
        began=time.perf_counter()
        replies=[pipe.call('decision') for _ in range(6)]
        elapsed=time.perf_counter()-began
        assert all(r==initial for r in replies)
        pipe.call('step',choice=initial['choices'][0]['id'])
        assert pipe.call('restore',checkpoint=checkpoint)==initial
        return dict(seconds=elapsed,response_bytes=len(json.dumps(initial)),candidates=len(initial['choices']))

results=[]
for buffered in (False,True,False,True):
    began=time.perf_counter()
    with ThreadPoolExecutor(max_workers=4) as pool:
        values=list(pool.map(lane,[buffered]*4))
    results.append(dict(buffered=buffered,wall_seconds=time.perf_counter()-began,lanes=values))
    print(json.dumps(results[-1]),flush=True)
raw=statistics.median(sum(x['seconds'] for x in r['lanes']) for r in results if not r['buffered'])
fast=statistics.median(sum(x['seconds'] for x in r['lanes']) for r in results if r['buffered'])
Path(__file__).with_name('transport-benchmark.json').write_text(json.dumps(dict(results=results,speedup=raw/fast),indent=2)+'\n')
print('speedup',raw/fast)
