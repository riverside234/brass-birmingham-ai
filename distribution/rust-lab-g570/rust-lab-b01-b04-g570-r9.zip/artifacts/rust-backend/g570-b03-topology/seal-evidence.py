"""Seal r9 launcher checks while retaining exact r8 runtime and earlier passes."""
import gzip,hashlib,json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.step5.league import implementation_id
from brass_ai.rust_backend.lab_teacher_overlay import source_fingerprint

def read(path):return json.loads(path.read_bytes())
def write(path,value):path.write_bytes((json.dumps(value,indent=2,allow_nan=False)+'\n').encode())
package=ROOT/'distribution/rust-lab-g570'
with zipfile.ZipFile(package/'rust-lab-b01-b04-g570-r8.zip') as archive:
 old= json.loads(archive.read('distribution/rust-lab-g570/transfer-manifest.json'))
 checks=json.loads(archive.read('distribution/rust-lab-g570/local-development.json'))
 assert implementation_id()==old['implementation'] and source_fingerprint()==old['producer']
 for name in old['files']:
  if name.startswith(('src/','configs/','lab-native/','training/')) or name=='distribution/rust-lab-g570/prerequisite-reuse.json':
   assert (ROOT/name).read_bytes()==archive.read(name),name
latest=ROOT/'results/rust-lab-qualification/20261104T014313172885Z-20261104T014145936407Z-g570-all-8a6142e0-696c1276'
manifest=read(latest/'export-manifest.json')
for item in manifest['files']:
 raw=(latest/item['path']).read_bytes()
 if not item['gzip']:raw=raw.replace(b'\r\n',b'\n')
 assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],item['path']
 if item['gzip']:
  value=gzip.decompress(raw)
  assert len(value)==item['source_bytes'] and hashlib.sha256(value).hexdigest()==item['source_sha256']
assert 'CUDA device topology differs on resume' in (latest/'evidence/b03/lab-checks.log').read_text()
assert not read(latest/'evidence/b03/qualification.json')['passed']
tests=read(OUT/'regression.json');assert tests['passed']
export_tests=read(OUT/'export.json');assert export_tests['passed']
files=['scripts/prepare-rust-lab-g570.py','scripts/run-rust-lab-qualification.py',
       'scripts/qualify-rust-lab-b03.py','tests/RustBackendLab/test_b03_topology.py']
review=dict(passed=True,implementation=implementation_id(),producer=source_fingerprint(),
 tests=tests,export_tests=export_tests,tested_files={name:sha(ROOT/name) for name in files},runtime_source_changed=False,
 prerequisites_repeated=False,preserved_passes=checks['b03_cuda_fix']['preserved_passes'],
 restart_at='b03',allow_cuda_topology_change=True,learner_device='cuda:0',
 source_report=latest.relative_to(ROOT).as_posix(),verified_export_files=manifest['files'],
 new_games=0,optimizer_steps=0,lab_qualification='B01/B02/B02.5 original passes retained; B03/B04 Pending',
 limitations=['CPU-only development; actual CUDA restoration remains a lab check.',
              'GPU topology regression mocks only CUDA hardware; real Adam and CPU RNG restoration are exercised.'])
write(OUT/'review.json',review)
checks.update(b03_topology_fix=review,scope='R9 launcher exposes the existing B03 logical-GPU RNG compatibility option. R8 trainer/source/reuse reviews and original passing prerequisites unchanged.')
for path in OUT.iterdir():
 if path.is_file() and path.suffix in ('.py','.json','.log'):
  checks['logs'][path.relative_to(ROOT).as_posix()]=sha(path)
write(package/'local-development.json',checks)
print(json.dumps(dict(passed=True,implementation=implementation_id(),tests=tests['tests'],runtime_source_changed=False)))
