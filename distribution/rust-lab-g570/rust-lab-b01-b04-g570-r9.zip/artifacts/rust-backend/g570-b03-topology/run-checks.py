import json,os,re,subprocess,sys,time
from pathlib import Path
root=Path.cwd();out=root/'artifacts/rust-backend/g570-b03-topology'
env=dict(os.environ,PYTHONPATH=os.pathsep.join(str(root/n) for n in ('src','scripts','tests/R2','tests/Recovery','tests/FeatureEngineering','tests/RustBackendLab')),CUDA_VISIBLE_DEVICES='')
command=[sys.executable,'-X','utf8','-m','unittest','-v','test_b03_topology','test_b03_cuda_restore','test_b03','test_qualification_runner','test_lab_transfer']
with (out/'regression.log').open('wb') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
text=(out/'regression.log').read_text(encoding='utf-8')
print(text[-4500:])
assert result.returncode==0
match=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK(?: \(skipped=(\d+)\))?\s*$',text)
assert match
report=dict(passed=True,tests=int(match[1]),seconds=float(match[2]),skipped=int(match[3] or 0),command=command)
(out/'regression.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps(report))
