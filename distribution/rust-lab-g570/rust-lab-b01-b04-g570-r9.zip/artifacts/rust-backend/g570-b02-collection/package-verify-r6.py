"""Verify a fresh r6 extraction and exercise its repaired reference bootstrap."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT/'src'))
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.rust_backend.lab_transfer import verify, DIRECTORY
from brass_ai.step5.league import write_json


def main():
    receipt = json.loads((ROOT/DIRECTORY/'bundle.json').read_text(encoding='utf-8'))
    manifest = json.loads((ROOT/DIRECTORY/'transfer-manifest.json').read_text(encoding='utf-8'))
    assert receipt['path'].endswith('rust-lab-b01-b04-g570-r6.zip')
    stages = [verify(s) for s in ('b01', 'b02', 'b025', 'b03', 'b04')]
    detached = ROOT/'artifacts/r6'
    assert not detached.exists(), 'Use a new short extraction directory'
    with zipfile.ZipFile(ROOT/receipt['path']) as archive:
        assert archive.testzip() is None
        for name, expected in manifest['files'].items():
            raw = archive.read(name)
            assert raw == (ROOT/name).read_bytes(), name
            assert hashlib.sha256(raw.replace(b'\r\n', b'\n')).hexdigest() == expected
        for name, expected in manifest['archives'].items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == expected
        assert not any(n.startswith('results/rust-lab-qualification/') and n != 'results/rust-lab-qualification/README.md'
                       for n in archive.namelist())
        archive.extractall(detached)
    shutil.copyfile(ROOT/DIRECTORY/'bundle.json', detached/DIRECTORY/'bundle.json')
    shutil.copyfile(ROOT/receipt['path'], detached/receipt['path'])
    # This detached extraction is a standalone Git fixture, so ignore-rule
    # tests inspect its own .gitignore rather than the enclosing artifacts tree.
    subprocess.run(['git', 'init', '--quiet', str(detached)], check=True,
                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
    # Only the pre-existing private rules dependencies are supplied externally.
    # The compiler must come solely from the freshly extracted public package.
    shutil.copytree(ROOT/'artifacts/r1-host/guarded', detached/'artifacts/r1-host/guarded')
    for name in ('throughput/ordinary', 'throughput/search', 'local-scoring/ordinary'):
        source = ROOT/'training/runtime'/name
        shutil.copyfile(source/'BrassHost.exe', detached/'training/runtime'/name/'BrassHost.exe')
    # A supplement overlays the existing matching checkout. Supply the baseline
    # host sources that its private runtime manifest also verifies, just as on
    # the lab. They are already present in the passing B01 source inventory.
    baseline_sources = {}
    for metadata in (ROOT/'training/runtime').rglob('runtime.json'):
        for name, expected in json.loads(metadata.read_text(encoding='utf-8')).get('authored_sources', {}).items():
            source = (ROOT/name).resolve(); destination = (detached/name).resolve()
            assert source.is_relative_to(ROOT) and destination.is_relative_to(detached)
            assert hashlib.sha256(source.read_bytes().replace(b'\r\n', b'\n')).hexdigest() == expected
            if not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
                baseline_sources[name] = expected
    env = dict(os.environ)
    env['PYTHONPATH'] = str(detached/'src')
    env['CUDA_VISIBLE_DEVICES'] = ''
    script = detached/'artifacts/rust-backend/g570-review/run-checks.py'
    commands = [
        ('integrity', [sys.executable, '-X', 'utf8', '-c',
            'from brass_ai.rust_backend.lab_transfer import verify; print([verify(s)["milestone"] for s in ("b01","b02","b025","b03","b04")])'], 45),
        ('harness', [sys.executable, '-X', 'utf8', str(script), '--out', 'artifacts/r6-tests',
            'test_b02_collection_fix', 'test_b02', 'test_lab_transfer'], 60),
        ('bootstrap', [sys.executable, '-X', 'utf8', str(script), '--out', 'artifacts/r6-host', '--bootstrap'], 60),
    ]
    for name, argv, timeout in commands:
        print('Fresh bundle: '+name, flush=True)
        with (OUT/('extracted-'+name+'.log')).open('wb') as log:
            result = subprocess.run(argv, cwd=detached, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
        assert result.returncode == 0, name
    spec = importlib.util.spec_from_file_location('r6_evidence', ROOT/'artifacts/rust-backend/g570-review/seal-evidence.py')
    evidence = importlib.util.module_from_spec(spec); spec.loader.exec_module(evidence)
    suite = evidence.test_summary(detached/'artifacts/r6-tests/tests.log')
    assert suite['tests'] >= 40 and suite['skipped'] == 0
    smoke = json.loads((detached/'artifacts/r6-host/bootstrap-smoke.json').read_text(encoding='utf-8'))
    assert smoke['passed'] and smoke['checkpoint_restored']
    # Copy only reports; never proprietary runtime or original lab results.
    review = OUT/'extracted-checks'; review.mkdir()
    for origin in ('r6-tests/tests.log', 'r6-tests/checks.json', 'r6-host/checks.json',
                   'r6-host/bootstrap-smoke.json', 'r6-host/compiler-preflight.log', 'r6-host/bootstrap-build.log'):
        target = review/origin; target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(detached/'artifacts'/origin, target)
    result = dict(passed=True, archive=receipt, transfer_stages=stages,
        fresh_extraction=True, payload_bytes_and_crc=True, public_compiler_restored=True,
        baseline_host_sources=baseline_sources,
        fixture_tests=suite, bootstrap=smoke, original_result_folders_untouched=True,
        scope='Fresh bundle integrity, harness and reference-host startup/restore only; B02-B04 Linux/CUDA gates Pending',
        logs={p.relative_to(ROOT).as_posix():sha(p) for p in [Path(__file__), *OUT.glob('extracted-*.log'),
            *[q for q in review.rglob('*') if q.is_file()]]})
    write_json(OUT/'package-check.json', result)
    write_json(ROOT/DIRECTORY/'package-check.json', result)
    print(json.dumps(dict(passed=True, tests=suite, bootstrap=smoke['passed'])))


if __name__ == '__main__': main()
