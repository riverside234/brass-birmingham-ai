"""Record exact same-recipe continuation for the B02 runtime/worker repair."""
import copy,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.recovery.source_reviews import expand_source_reviews,compact_source_reviews
from brass_ai.step5.league import implementation_id,implementation_sources,write_json
from brass_ai.learning.contracts import digest
from brass_ai.rust_backend.lab_contract import sha

path=ROOT/'configs/learning/selfplay-resume-sources.json'
baseline=OUT/'source-reviews-before.json'
assert not baseline.exists()
baseline.write_bytes(path.read_bytes());previous=sha(path)
original=expand_source_reviews(json.loads(baseline.read_text(encoding='utf-8')))
updated=copy.deepcopy(original);current=implementation_id()
prior='70a926e5dfc7aa30829c296b49cb7b53159534ccc5e7c8876c46a9609a44164d'
state=json.loads((ROOT/'results/joint7-v11-2-g1290-trained-restart-g0570-20261103T190804654465Z/state.json').read_text())
origins={prior,state['signature']['implementation'],
 '603d1d236ca3da4511467956a9b656b41a4f03017d814b1abd8f060467a4c05c',
 '6abba7672db47057df6090907c9397eb70ecad52b691653ed552bf250725e96d'}
reason=('B02 qualification repair: canonical source verification for an already pinned current shared V4 runtime; '
 'binary/dependency/manifest and semantic source checks preserved. Raise bounded smoke worker ceiling to 60, '
 'retain three frozen parent families and branch coverage; early reference preflight and partial-setup cleanup. '
 'No model, optimizer, reward, search, training recipe or saved-state change. Actual Linux/CUDA gates Pending.')
for item in original['transitions']:
 if item['to_implementation']==prior and item['from_implementation'] in origins and not item.get('config_migrations'):
  updated['transitions'].append(dict(item,to_implementation=current,reason=reason,
   review_report='ai-research/RUST_BACKEND_B02_COLLECTION_FIX.md'))
for fields in ({},{'teacher_phase_changes':True},{'config_migrations':['teacher-phase-adoption/1.0.0']}):
 for source in (prior,state['signature']['implementation'],current):
  updated['transitions'].append(dict(from_implementation=source,to_implementation=current,
   learning_compatibility=digest(state['signature']['compatibility']),reason=reason,
   review_report='ai-research/RUST_BACKEND_B02_COLLECTION_FIX.md',preserve_g370_calibration=True,
   preserve_g570_calibration=True,**fields))
assert sha(path)==previous
write_json(path,compact_source_reviews(updated))
write_json(OUT/'source-review.json',dict(implementation=current,previous=prior,registry=sha(path),
 added=len(updated['transitions'])-len(original['transitions']),reason=reason))
import zipfile
with zipfile.ZipFile(ROOT/'distribution/rust-lab-g570/rust-lab-b01-b04-g570-r5.zip') as z:
 changes=[n for n,text in implementation_sources().items()
          if z.read(n).decode('utf-8').replace('\r\n','\n')!=text]
assert set(changes)=={'src/brass_ai/legacy.py','src/brass_ai/rust_backend/lab_b02_smoke.py'},list(changes)
write_json(OUT/'changed-implementation-inputs.json',list(changes))
print(current)
