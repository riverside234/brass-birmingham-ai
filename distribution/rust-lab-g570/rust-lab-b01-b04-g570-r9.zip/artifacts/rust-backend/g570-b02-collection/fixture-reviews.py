"""Retain the existing exact teacher-adoption fixture routes for the new source."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.recovery.source_reviews import expand_source_reviews,compact_source_reviews
from brass_ai.step5.league import implementation_id,write_json
from brass_ai.rust_backend.lab_contract import sha
path=ROOT/'configs/learning/selfplay-resume-sources.json';stamp=json.loads((OUT/'source-review.json').read_text())
assert sha(path)==stamp['registry']
data=expand_source_reviews(json.loads(path.read_text()))
old=expand_source_reviews(json.loads((OUT/'source-reviews-before.json').read_text()))
for item in old['transitions']:
 if (item['to_implementation']==stamp['previous'] and
     item['from_implementation'] in {'603d1d236ca3da4511467956a9b656b41a4f03017d814b1abd8f060467a4c05c',
                                    '6abba7672db47057df6090907c9397eb70ecad52b691653ed552bf250725e96d'}
     and item.get('config_migrations')==['teacher-phase-adoption/1.0.0']):
  data['transitions'].append(dict(item,to_implementation=implementation_id(),reason=stamp['reason'],
   review_report='ai-research/RUST_BACKEND_B02_COLLECTION_FIX.md'));stamp['added']+=1
write_json(path,compact_source_reviews(data));stamp['registry']=sha(path);write_json(OUT/'source-review.json',stamp)
print(stamp['added'])
