"""Bind r6 evidence and preserve the reviewed full-checkpoint continuation."""
import hashlib,importlib.util,json,re,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_contract import sha
from brass_ai.step5.league import implementation_id,write_json
from brass_ai.recovery.resume import check_signature

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def summary(p):
 t=p.read_text(encoding='utf-8');m=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK(?: \(skipped=(\d+)\))?\s*$',t)
 assert m,p
 return dict(tests=int(m[1]),seconds=float(m[2]),skipped=int(m[3] or 0))

package=ROOT/'distribution/rust-lab-g570'
with zipfile.ZipFile(package/'rust-lab-b01-b04-g570-r5.zip') as z:
 checks=json.loads(z.read('distribution/rust-lab-g570/local-development.json'))
registry=ROOT/'configs/learning/selfplay-resume-sources.json'
# Keep this deliberately byte-tracked registry in LF, as in the prior checkout.
data=registry.read_bytes().replace(b'\r\n',b'\n')
if registry.read_bytes()!=data:
 temp=registry.with_suffix('.lf.tmp');temp.write_bytes(data);temp.replace(registry)
stamp=read(OUT/'source-review.json');stamp['registry']=sha(registry);write_json(OUT/'source-review.json',stamp)
state=read(ROOT/'results/joint7-v11-2-g1290-trained-restart-g0570-20261103T190804654465Z/state.json')
assert implementation_id()==stamp['implementation']
check_signature(state,dict(state['signature'],implementation=implementation_id()),reviewed=True)
tests={name:summary(OUT/path) for name,path in [('focused','focused-pass/tests.log'),
 ('continuation','continuation-pass/tests.log'),('b01_adapter','b01/adapter-tests.log'),('b01_inference','b01/existing-inference-tests.log')]}
evidence=OUT/'lab-evidence';exported=read(evidence/'export-manifest.json');verified=[]
for item in exported['files']:
 p=evidence/item['path']
 if p.exists():
  assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes'];verified.append(item['path'])
assert read(evidence/'evidence/b02/collection-smoke.json')['passed'] is False
files=['src/brass_ai/legacy.py','src/brass_ai/rust_backend/lab_b02_smoke.py',
 'scripts/qualify-rust-lab-b02.py','scripts/run-rust-lab-qualification.py',
 'tests/RustBackendLab/test_b02_collection_fix.py']
review=dict(passed=True,implementation=implementation_id(),worker_cap=60,tests=tests,
 tested_files={n:sha(ROOT/n) for n in files},source_review_sha256=sha(registry),verified_lab_files=verified,
 lab_qualification='Pending: rerun B01-B04 for changed executable source',
 limitations=['One optional broad rating-plot test could not run without matplotlib; focused frozen-runtime checks passed.',
 'Windows symlink and two optional built-native teacher checks skipped; actual Linux/CUDA gates remain on lab.'])
write_json(OUT/'review.json',review)
checks.update(implementation=implementation_id(),source_review_sha256=sha(registry),collection_fix=review,
 scope='R6 shared V4 text identity and 60-worker-cap diagnostic smoke; full g570 continuation preserved.',lab_qualification='Pending')
checks['b01_python_fix'].update(adapter=tests['b01_adapter'],inference=tests['b01_inference'],
 trainer_source_unchanged=False,source_reviews_unchanged=False)
checks['b01_python_fix']['tested_files']={n:sha(ROOT/n) for n in checks['b01_python_fix']['tested_files']}
logs=[p for p in OUT.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.py') and p.name!='source-reviews-before.json']
checks['logs'].update({p.relative_to(ROOT).as_posix():sha(p) for p in logs})
write_json(package/'local-development.json',checks)
print(json.dumps(dict(passed=True,tests=tests,implementation=implementation_id())))
