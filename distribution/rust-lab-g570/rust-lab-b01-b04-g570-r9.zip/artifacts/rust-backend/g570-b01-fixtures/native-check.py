"""Check all native test targets without a long cold release link or gameplay."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_contract import native_fingerprint,SOURCE,sha

def module(name):
    spec=importlib.util.spec_from_file_location(name.replace('-','_'),ROOT/'scripts'/name)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result

base=module('qualify-rust-lab.py')
scaffold=module('qualify-rust-scaffold.py')
native=OUT/'checkout/native'
inputs=base.prepare_test_inputs(native)
env,cargo=scaffold.tool_environment()
env.update(CARGO_INCREMENTAL='0',PROPTEST_RNG_SEED='890',PROPTEST_CASES='16')
argv=[str(cargo),'+1.99.1','check','--release','-p','brass-ai-core','-p','brass-ai-worker','--tests',
    '--manifest-path',str(native/'Cargo.toml'),'--target','x86_64-pc-windows-gnu',
    '--target-dir',str(OUT/'target'),'--locked','--offline']
began=time.monotonic()
with (OUT/'native-check.log').open('wb') as log:
    run=subprocess.run(argv,cwd=native,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert run.returncode==0,run.returncode
assert native_fingerprint(native)==SOURCE
value=dict(passed=True,platform='Windows x86_64-pc-windows-gnu',native_inputs=inputs,argv=argv,
    seconds=time.monotonic()-began,log_sha256=sha(OUT/'native-check.log'),native_source_unchanged=True,
    native_test_execution=False,cold_release_build='Stopped at 300-second compile bound before native test execution',
    lab_qualification='Pending',scope='cargo check --release --tests for core and worker from the sealed detached source; no CUDA/checkpoint load')
base.write(OUT/'native-check.json',value)
print(json.dumps(dict(passed=True,seconds=value['seconds'],lab_qualification='Pending')),flush=True)
