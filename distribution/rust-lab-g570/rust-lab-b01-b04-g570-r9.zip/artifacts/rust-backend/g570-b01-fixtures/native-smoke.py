"""Bounded Windows smoke of the exact detached B01 native archive and test set."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_contract import extract_new,native_fingerprint,SOURCE,sha,verify_inputs

def module(name):
    spec=importlib.util.spec_from_file_location(name.replace('-','_'),ROOT/'scripts'/name)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result

base=module('qualify-rust-lab.py')
scaffold=module('qualify-rust-scaffold.py')
extract_new(ROOT/'distribution/rust-lab-b01/b01-search-v1-inputs.zip',OUT/'inputs')
verify_inputs(OUT/'inputs',json.loads((ROOT/'configs/search/lab-search-v1.json').read_text()))
extract_new(OUT/'inputs/source.zip',OUT/'checkout')
native=OUT/'checkout/native'
try:
    base.check_compile_inputs(native)
except ValueError as error:
    missing=str(error)
    assert 'Missing Rust compile input: tests/GumbelISMCTS/fixtures/' in missing
else:
    raise AssertionError('Original archive unexpectedly contains the external fixtures')
inputs=base.prepare_test_inputs(native)
assert native_fingerprint(native)==SOURCE
env,cargo=scaffold.tool_environment()
env.update(CARGO_INCREMENTAL='0',PROPTEST_RNG_SEED='890',PROPTEST_CASES='16')
common=['--manifest-path',str(native/'Cargo.toml'),'--target','x86_64-pc-windows-gnu',
        '--target-dir',str(OUT/'target'),'--locked','--offline']
core=[str(cargo),'+1.99.1','test','--release','-p','brass-ai-core','--lib']
for name in ('contracts','state','rules','privacy','simulation','features','search','sessions','cooperative'):
    core+=['--test',name]
core+=common+['--','--test-threads=2','--skip','both_one_and_neither_owner_hit_without_sharing_counts_or_root_credit',
    '--skip','reused_owner_rejects_changed_value_sampler_information_and_cancellation']
worker=[str(cargo),'+1.99.1','test','--release','-p','brass-ai-worker','--lib',*common,'--','--test-threads=2']
commands=[]
for name,argv in (('core-tests',core),('worker-tests',worker)):
    began=time.monotonic()
    with (OUT/(name+'.log')).open('wb') as log:
        run=subprocess.run(argv,cwd=native,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    commands.append(dict(name=name,argv=argv,exit_code=run.returncode,seconds=time.monotonic()-began,
                         sha256=sha(OUT/(name+'.log'))))
    print(json.dumps(commands[-1]),flush=True)
    assert run.returncode==0,(name,run.returncode)
assert native_fingerprint(native)==SOURCE
base.write(OUT/'native-smoke.json',dict(passed=True,platform='Windows x86_64-pc-windows-gnu',
    reproduced_original_missing_input=missing,native_inputs=inputs,commands=commands,
    native_source_unchanged=True,lab_qualification='Pending',
    scope='Exact B01 native source and test selection; local compiler only, no CUDA or checkpoint load'))
