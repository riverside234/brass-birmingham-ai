"""Verify r2's fresh extraction and actual nested archive fixture preparation."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.rust_backend.lab_transfer import DIRECTORY,RETIRED,verify
from brass_ai.step5.league import write_json
from brass_ai.rust_backend.lab_contract import sha

receipt=json.loads((ROOT/DIRECTORY/'bundle.json').read_text())
manifest=json.loads((ROOT/DIRECTORY/'transfer-manifest.json').read_text())
stages=[verify(stage) for stage in ('b01','b02','b025','b03','b04')]
archive=ROOT/receipt['path']
detached=OUT/'extracted-package'
assert not detached.exists()
assert archive.name=='rust-lab-b01-b04-g570-r2.zip'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not set(RETIRED).intersection(z.namelist())
    assert set(manifest['native_test_inputs']['fixtures']).issubset(z.namelist())
    for name,expected in manifest['files'].items():
        raw=z.read(name)
        assert raw==(ROOT/name).read_bytes(),name
        assert hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()==expected,name
    for name,expected in manifest['archives'].items():
        assert hashlib.sha256(z.read(name)).hexdigest()==expected,name
    z.extractall(detached)
shutil.copyfile(ROOT/DIRECTORY/'bundle.json',detached/DIRECTORY/'bundle.json')
shutil.copyfile(archive,detached/receipt['path'])
env={k:v for k,v in os.environ.items() if not k.startswith('BRASS_B04_')}
env['PYTHONPATH']=os.pathsep.join(str(detached/n) for n in ('src','tests/RustBackendLab'))
commands=[('extracted-inputs',[sys.executable,'-X','utf8','-m','unittest','test_b01_inputs','-v']),
    ('extracted-launcher',[sys.executable,'-X','utf8',str(detached/'scripts/run-rust-lab-qualification.py'),
      '--stage','b04','--fixtures-only','--device','cpu'])]
tests={}
for name,argv in commands:
    with (OUT/(name+'.log')).open('w',encoding='utf-8') as log:
        run=subprocess.run(argv,cwd=detached,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    assert run.returncode==0,(name,run.returncode)
    text=(OUT/(name+'.log')).read_text()
    if name=='extracted-launcher':
        fixture=next((detached/'artifacts/rust-backend').glob('*/b04/fixtures.log'))
        text=fixture.read_text()
    result=re.search(r'Ran (\d+) tests in ([0-9.]+)s',text)
    assert result and re.search(r'^OK(?: \(skipped=\d+\))?\s*$',text,re.M)
    tests[name]=int(result[1])
exports=list((detached/'results/rust-lab-qualification').glob('*/evidence/runner.json'))
assert len(exports)==1 and json.loads(exports[0].read_text())['passed']
probe=detached/'src/brass_ai/recovery/unreviewed_probe.py'
assert not probe.exists() and probe.resolve().is_relative_to(detached.resolve())
probe.write_text('# authored unreviewed dependency\n')
try:
    with (OUT/'extra-module-rejection.log').open('w',encoding='utf-8') as log:
        rejected=subprocess.run(commands[-1][1],cwd=detached,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
    assert rejected.returncode!=0
    second=set((detached/'results/rust-lab-qualification').glob('*/evidence/runner.json'))-set(exports)
    assert len(second)==1
    failure=json.loads(second.pop().read_text())
    assert not failure['passed'] and not failure['stages']
    assert 'added (1): src/brass_ai/recovery/unreviewed_probe.py' in failure['error']
finally:
    probe.unlink()
for path in (ROOT/DIRECTORY).iterdir():
    assert subprocess.run(['git','check-ignore','-q','--no-index',path.relative_to(ROOT).as_posix()],cwd=ROOT).returncode==1,path
value=dict(passed=True,local_date='2026-11-03',archive=receipt,transfer_stages=stages,
    raw_payload_and_crc='passed',extracted_tests=tests,added_unreviewed_module_rejected=True,
    failure_export_verified=True,success_export_verified=True,native_source_unchanged=True,
    lab_qualification='Pending',scope='Local Windows CPU/package integrity; actual g570 checkpoint and CUDA require lab rerun',
    logs={(OUT/n).relative_to(ROOT).as_posix():sha(OUT/n) for n in
        ('extracted-inputs.log','extracted-launcher.log','extra-module-rejection.log')})
write_json(OUT/'package-check.json',value)
write_json(ROOT/DIRECTORY/'package-check.json',value)
print(json.dumps(dict(passed=True,extracted_tests=tests,extra_module_rejected=True,lab_qualification='Pending')),flush=True)
