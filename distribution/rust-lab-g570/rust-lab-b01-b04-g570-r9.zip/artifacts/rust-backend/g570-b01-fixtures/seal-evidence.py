"""Bind the fixture-only delta to the unchanged reviewed g570 implementation."""
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).parent
PACKAGE=ROOT/'distribution/rust-lab-g570'
sys.path.insert(0,str(ROOT/'src'))
from brass_ai.step5.league import implementation_id,write_json
from brass_ai.rust_backend.lab_teacher_overlay import source_fingerprint
from brass_ai.rust_backend.lab_contract import sha

archive=PACKAGE/'rust-lab-b01-b04-g570.zip'
assert sha(archive)=='7bbceb50b1b2ffa3c3797aa2aae452a90edde2f15be8a2d627b452f7c64a53a4'
with zipfile.ZipFile(archive) as z:
    checks=json.loads(z.read('distribution/rust-lab-g570/local-development.json'))
    old=json.loads(z.read('distribution/rust-lab-g570/transfer-manifest.json'))
assert implementation_id()==checks['implementation']
assert source_fingerprint()==checks['producer']
assert sha(ROOT/'configs/learning/selfplay-resume-sources.json')==checks['source_review_sha256']
for name,expected in old['implementation_files'].items():
    assert hashlib.sha256((ROOT/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==expected,name
text=(OUT/'fixtures.log').read_text(encoding='utf-8-sig')
result=re.search(r'Ran (\d+) tests in ([0-9.]+)s',text)
assert result and 'OK (skipped=1)' in text
native=json.loads((OUT/'native-check.json').read_text())
assert native['passed'] and native['native_source_unchanged']
assert not native['native_test_execution']
assert sha(OUT/'native-check.log')==native['log_sha256']
checks['b01_inputs_fix']=dict(passed=True,fixture_tests=int(result[1]),seconds=float(result[2]),skipped=1,
    native_inputs=native['native_inputs'],native_compile_check=native,platform=native['platform'],
    reproduced_original_missing_input=True,
    trainer_source_unchanged=True,source_reviews_unchanged=True,old_archive_unchanged=True)
for name in ('fixtures.log','native-check.json','native-check.log','native-check.py','native-smoke.log',
             'core-tests.log','native-smoke.py','seal-evidence.py','package-smoke.py'):
    checks['logs'][(OUT/name).relative_to(ROOT).as_posix()]=sha(OUT/name)
checks['previous_g570_checks_reused']=True
checks['scope']='g570-r2 detached native-fixture fix: all core/worker test targets compile-checked on Windows and bounded CPU regression checks. '
checks['scope']+='Prior g570 continuation checks retained because every trainer/native implementation input and source approval is unchanged. '
checks['scope']+='A cold release test build reached its 300-second compile bound; no native test execution is claimed. '
checks['scope']+='Actual Linux/CUDA B01 and g570 checkpoint qualification require a lab rerun; no game, training or search timing session run.'
write_json(PACKAGE/'local-development.json',checks)
print(json.dumps(dict(passed=True,python_tests=int(result[1]),native_compile_check=True,lab_qualification='Pending')))
